Please always provide the [GitHub issue(s)](../issues) your PR is for, as well as test URLs where your change can be observed (before and after):

Fix #<gh-issue-id>



Test URLs:

Please note, for testing urls, make sure to include the `lighthouse=on` URL parameter to bypass the Modal, and get the correct PSI Score.


- Before: https://main--takeda-ihs--hlxsites.hlx.page/?=lighthouse=on
- After: https://<branch>--takeda-ihs--hlxsites.hlx.page/?lighthouse=on
